package DAO;

import Model.TransacaoBancaria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TransacaoDAO {
    
    private Connection conn = null;

    public TransacaoDAO() {
        
    }

    public List<TransacaoBancaria> selectExtratoByIdPessoa(int id){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<TransacaoBancaria> extratos = new ArrayList<>();
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM `transacoesbancarias` WHERE fkPessoa = ? ORDER BY transacoesbancarias.dataTransacao DESC");            
            stmt.setInt(1, id);
            
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
              TransacaoBancaria extrato = new TransacaoBancaria();
              extrato.setId(rs.getInt("idTransacao"));
              extrato.setValor(rs.getDouble("valor"));
              extrato.setData(rs.getDate("dataTransacao"));
              extrato.setTipo(rs.getString("tipo"));
              
              extratos.add(extrato);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR EXTRATO DO CLIENTE: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        
        return extratos;
    }
    
    public void create(double valor, int idPessoa, String tipo) {
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;       
        
        try {
            
            stmt = conn.prepareStatement("INSERT INTO `transacoesbancarias`(`fkPessoa`, `valor`, `tipo`) VALUES (?, ?, ?)");            
            stmt.setInt(1, idPessoa);
            stmt.setDouble(2, valor);
            stmt.setString(3, tipo);
            
            int resul = stmt.executeUpdate();
                
            if(resul > 0){
                JOptionPane.showMessageDialog(null, "Transação Efetuada com Sucesso.");
            }
            else{
                JOptionPane.showMessageDialog(null, "ERRO ao Efeturar Transação.");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR FAZER UMA NOVA TRANSAÇÃO: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt);
        }
      
    }
    
    
    
    
    
}
