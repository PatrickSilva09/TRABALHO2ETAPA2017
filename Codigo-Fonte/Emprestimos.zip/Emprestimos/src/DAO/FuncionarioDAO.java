package DAO;

import Model.Cliente;
import Model.Funcionario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class FuncionarioDAO {
    private Connection conn = null;
    private ResultSet resul;
    
    
    
    public Funcionario selectFuncionarioById(int id){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        Funcionario func = new Funcionario();
        
        try {
            
            stmt = conn.prepareStatement("SELECT idPessoa,nome,cpf,endereco,numeroEndereco, cep, email, usuariosistema.tipo AS tipoUsuario, idFuncionario, cargo, idUsuario, senha, usuario, status  FROM `usuariosistema`, (SELECT * from pessoas,funcionarios WHERE funcionarios.fkPessoa = idPessoa) AS funcionario WHERE usuariosistema.fkPessoa = idPessoa AND usuariosistema.status = 'A' AND  idUsuario = ?");            
            stmt.setInt(1, id);
            
            resul = stmt.executeQuery();
            
            while (resul.next()) {
               func.setIdPessoa(resul.getInt("idPessoa"));
               func.setNome(resul.getString("nome"));
               func.setCpf(resul.getString("cpf"));
               func.setEndereco(resul.getString("endereco"));
               func.setNumeroEndereco(resul.getInt("numeroEndereco"));
               func.setCep(resul.getString("cep"));
               func.setEmail(resul.getString("email"));
               func.setTipo(resul.getString("tipoUsuario"));
               func.setIdFuncionario(resul.getInt("idFuncionario"));
               func.setCargo(resul.getString("cargo"));
               func.setIdUsuario(resul.getInt("idUsuario"));
               func.setSenha(resul.getString("senha"));
               func.setUsuario(resul.getString("usuario"));
               func.setStatus(resul.getString("status"));
                          
            }
            
            return func;
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR FUNCIONARIO NO SISTEMA: Verifique Com o Administrador !! "+ex);
            return null;
        } 
        finally{
            ConnectionDB.closeConnection(conn, stmt);
        }
    }
    
}
