package DAO;

import Model.Emprestimo;
import Model.TransacaoBancaria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class EmprestimoDAO {
    private Connection conn = null;    
    
    
    public List<Emprestimo> selectEmprestimoPendentes(){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Emprestimo> emprestimos = new ArrayList<>();
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM `emprestimos`,`pessoas` WHERE status='P' AND fkPessoa = idPessoa ORDER BY emprestimos.dataSolicitacao DESC");            
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
              Emprestimo emprestimo = new Emprestimo();
              emprestimo.setIdEmprestimo(rs.getInt("idEmprestimo"));
              emprestimo.setDescricao(rs.getString("descricao"));
              emprestimo.setDataSolicitacao(rs.getDate("dataSolicitacao"));
              emprestimo.setDataAprovacao(rs.getDate("dataAprovacao"));
              emprestimo.setValorSolicitado(rs.getDouble("valorSolicitado"));
              emprestimo.setNumeroParcelas(rs.getInt("numeroParcelas"));
              emprestimo.setIdPessoa(rs.getInt("fkPessoa"));
              emprestimo.setNome(rs.getString("nome"));
              emprestimo.setStatus(rs.getString("status"));

              
              emprestimos.add(emprestimo);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR EMPRESTIMOS: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        
        return emprestimos;
    }
    
    public List<Emprestimo> selectAllEmprestimo(){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Emprestimo> emprestimos = new ArrayList<>();
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM `emprestimos`,`pessoas` WHERE fkPessoa = idPessoa ORDER BY emprestimos.dataSolicitacao DESC");            
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
              Emprestimo emprestimo = new Emprestimo();
              emprestimo.setIdEmprestimo(rs.getInt("idEmprestimo"));
              emprestimo.setDescricao(rs.getString("descricao"));
              emprestimo.setDataSolicitacao(rs.getDate("dataSolicitacao"));
              emprestimo.setDataAprovacao(rs.getDate("dataAprovacao"));
              emprestimo.setValorSolicitado(rs.getDouble("valorSolicitado"));
              emprestimo.setNumeroParcelas(rs.getInt("numeroParcelas"));
              emprestimo.setIdPessoa(rs.getInt("fkPessoa"));
              emprestimo.setNome(rs.getString("nome"));
              emprestimo.setStatus(rs.getString("status"));

              
              emprestimos.add(emprestimo);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR EMPRESTIMOS: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        
        return emprestimos;
    }
    
    
    public Emprestimo selectEmprestimoById(int idEmprestimo){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        Emprestimo emprestimo = new Emprestimo();
        ResultSet rs = null;
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM `emprestimos`,`pessoas` WHERE idEmprestimo = ? AND fkPessoa = idPessoa");
            stmt.setInt(1, idEmprestimo);
            
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
              emprestimo.setIdEmprestimo(rs.getInt("idEmprestimo"));
              emprestimo.setDescricao(rs.getString("descricao"));
              emprestimo.setDataSolicitacao(rs.getDate("dataSolicitacao"));
              emprestimo.setDataAprovacao(rs.getDate("dataAprovacao"));
              emprestimo.setValorSolicitado(rs.getDouble("valorSolicitado"));
              emprestimo.setNumeroParcelas(rs.getInt("numeroParcelas"));
              emprestimo.setIdPessoa(rs.getInt("fkPessoa"));
              emprestimo.setNome(rs.getString("nome"));
              emprestimo.setStatus(rs.getString("status"));
              
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR EMPRESTIMOS: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        return emprestimo;
    }
    
    
    public int updateStatusEmprestimo(int idEmprestimo, String status){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null; 
        int resul = 0;
        
        System.out.println(""+status);
        
        try {
            
            stmt = conn.prepareStatement("UPDATE `emprestimos` SET `status`= ? WHERE idEmprestimo = ?");            
            stmt.setString(1, status);
            stmt.setInt(2, idEmprestimo);
            
            resul = stmt.executeUpdate();
               
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR FAZER UMA ATUALIZAÇÃO NO EMRPESTIMO: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt);
        }
        
       return resul;
    }
    
    
    public void create(Emprestimo emp){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;       
        
        try {
            
            stmt = conn.prepareStatement("INSERT INTO `emprestimos`(`descricao`, `valorSolicitado`, `numeroParcelas`, `fkPessoa`, `status`) VALUES (?, ?, ?, ?, ?)");            
            stmt.setString(1, emp.getDescricao());
            stmt.setDouble(2, emp.getValorSolicitado());
            stmt.setInt(3, emp.getNumeroParcelas());
            stmt.setInt(4, emp.getIdPessoa());
            stmt.setString(5, emp.getStatus());
            
                       
            int resul = stmt.executeUpdate();
                           
            if(resul > 0){
                JOptionPane.showMessageDialog(null, "Emprestimo Solicitado Com Sucesso... Aguarde Aprovação.");            
            }
            else{
                JOptionPane.showMessageDialog(null, "ERRO AO SOLICITAR EMPRESTIMO - Verifique com o Administrador");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO DE EXECUÇÃO: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt);
        }
    }
}
