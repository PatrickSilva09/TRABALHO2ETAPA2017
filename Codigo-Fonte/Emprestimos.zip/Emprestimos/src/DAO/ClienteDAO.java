package DAO;

import Model.Cliente;
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ClienteDAO {
    private Connection conn;
    
    
    public ClienteDAO(){
        this.conn = null;
    }
    
    /**
    * TABELA DE ERROS NA TELA DO CLIENTE 
    *  001-C -> ERRO AO DA INSERT NA TABELA CLIENTE.
    *  002-P -> ERRO AO DA INSERT NA TABELA PESSOA.
     * @param cli CLIENTE 
    */
    public void create(Cliente cli){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;       
        
        try {
            
            stmt = conn.prepareStatement("INSERT INTO `pessoas`(`nome`, `cpf`, `endereco`, `numeroEndereco`, `cep`, `email`, `tipo`) VALUES (?, ?, ?, ?, ?, ?, ? )", Statement.RETURN_GENERATED_KEYS);            
            stmt.setString(1, cli.getNome());
            stmt.setString(2, cli.getCpf());
            stmt.setString(3, cli.getEndereco());
            stmt.setInt(4, cli.getNumeroEndereco());
            stmt.setString(5, cli.getCep());
            stmt.setString(6, cli.getEmail());
            stmt.setString(7, cli.getTipo());
            
            
            
            int resul = stmt.executeUpdate();
            
            //Pegando o Ultimo Id Inserido na Tabela Pessoas
            ResultSet retornoDoID = stmt.getGeneratedKeys();
            retornoDoID.next();
            
            // ATRIBUI O RETONO NO ID PESSOA
            Integer idPessoa = retornoDoID.getInt(1); 
                           
            if(resul > 0){
                stmt = conn.prepareStatement("INSERT INTO `clientes`(`salario`, `limite`, `fkPessoa`) VALUES (?, ?, ?)");
                stmt.setDouble(1, cli.getSalario());
                stmt.setDouble(2, cli.getLimite());
                stmt.setInt(3, idPessoa);
                
                int resul2 = stmt.executeUpdate();
                if(resul2 > 0){
                    JOptionPane.showMessageDialog(null, "Cliente Cadastrado Com Sucesso...");
                }
                else{
                    JOptionPane.showMessageDialog(null, "ERRO ao Efeturar Cadastro - Codigo Erro: 001-C.");
                }              
            }
            else{
                JOptionPane.showMessageDialog(null, "ERRO ao Efeturar Cadastro - Codigo Erro: 002-P.");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR FAZER UMA NOVA TRANSAÇÃO: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt);
        }
    }
    
    
    public List<Cliente> selectAllClientes(){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Cliente> clientes = new ArrayList<>();
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM clientes,pessoas WHERE fkPessoa = idPessoa AND tipo = 'C'");            
            rs = stmt.executeQuery();
            
            while (rs.next()) {
              Cliente cli = new Cliente();
              cli.setIdPessoa(rs.getInt("idPessoa"));
              cli.setNome(rs.getString("nome"));
              cli.setCpf(rs.getString("cpf"));
              cli.setEndereco(rs.getString("endereco"));
              cli.setNumeroEndereco(rs.getInt("numeroEndereco"));
              cli.setCep(rs.getString("cep"));
              cli.setEmail(rs.getString("email"));
              cli.setSaldo(rs.getDouble("saldo"));
              cli.setSalario(rs.getDouble("salario"));
              cli.setLimite(rs.getDouble("limite"));
             
              

              
              clientes.add(cli);
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR EMPRESTIMOS: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        
        return clientes;
    }
    
    public Cliente selectClienteById(int idPessoa){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        Cliente cli = new Cliente();
        ResultSet rs = null;
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM `clientes`,`pessoas` WHERE fkPessoa = idPessoa AND tipo ='C' AND idPessoa = ?");
            stmt.setInt(1, idPessoa);
            
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
              cli.setIdPessoa(rs.getInt("idPessoa"));
              cli.setNome(rs.getString("nome"));
              cli.setCpf(rs.getString("cpf"));
              cli.setEndereco(rs.getString("endereco"));
              cli.setNumeroEndereco(rs.getInt("numeroEndereco"));
              cli.setCep(rs.getString("cep"));
              cli.setEmail(rs.getString("email"));
              cli.setSaldo(rs.getDouble("saldo"));
              cli.setSalario(rs.getDouble("salario"));
              cli.setLimite(rs.getDouble("limite"));
              cli.setTipo(rs.getString("tipo"));
              cli.setIdCliente(rs.getInt("idCliente"));
              
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR CLIENTE: Verifique Com o Administrador !! "+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        return cli;
    }
    
    public Cliente selectClienteByCpf(String cpf){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;
        Cliente cli = new Cliente();
        ResultSet rs = null;
        
        try {
            
            stmt = conn.prepareStatement("SELECT * FROM `clientes`,`pessoas` WHERE fkPessoa = idPessoa AND tipo ='C' AND cpf = ?");
            stmt.setString(1, cpf);
            
            rs = stmt.executeQuery();
            
            while (rs.next()) {                
              cli.setIdPessoa(rs.getInt("idPessoa"));
              cli.setNome(rs.getString("nome"));
              cli.setCpf(rs.getString("cpf"));
              cli.setEndereco(rs.getString("endereco"));
              cli.setNumeroEndereco(rs.getInt("numeroEndereco"));
              cli.setCep(rs.getString("cep"));
              cli.setEmail(rs.getString("email"));
              cli.setSaldo(rs.getDouble("saldo"));
              cli.setSalario(rs.getDouble("salario"));
              cli.setLimite(rs.getDouble("limite"));
              
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR BUSCAR CLIENTE: Verifique Com o Administrador !! "+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt, rs);
        }
      
        return cli;
    }
    
    
    /**
    * TABELA DE ERROS NA TELA DO CLIENTE 
    *  003-C -> ERRO AO DA INSERT NA TABELA CLIENTE.
    *  004-P -> ERRO AO DA INSERT NA TABELA PESSOA.
     * @param cli CLIENTE 
    */
    public void update(Cliente cli){
        conn = ConnectionDB.getConnection();
        PreparedStatement stmt = null;       
        
        try {
            
            stmt = conn.prepareStatement("UPDATE `pessoas` SET `nome`= ?,`cpf`= ?,`endereco`= ?,`numeroEndereco`= ?,`cep`= ?,`email`= ? WHERE idPessoa = ?");            
            stmt.setString(1, cli.getNome());
            stmt.setString(2, cli.getCpf());
            stmt.setString(3, cli.getEndereco());
            stmt.setInt(4, cli.getNumeroEndereco());
            stmt.setString(5, cli.getCep());
            stmt.setString(6, cli.getEmail());
            stmt.setInt(7, cli.getIdPessoa());
            
            
            
            int resul = stmt.executeUpdate();
                                      
            if(resul > 0){
                stmt = conn.prepareStatement("UPDATE `clientes` SET `salario`= ?,`limite`= ? WHERE fkPessoa = ?");
                stmt.setDouble(1, cli.getSalario());
                stmt.setDouble(2, cli.getLimite());
                stmt.setInt(3, cli.getIdPessoa());
                
                int resul2 = stmt.executeUpdate();
                if(resul2 > 0){
                    JOptionPane.showMessageDialog(null, "Cliente Atualizado Com Sucesso...");
                }
                else{
                    JOptionPane.showMessageDialog(null, "ERRO ao Efeturar Atualização - Codigo Erro: 003-C.");
                }              
            }
            else{
                JOptionPane.showMessageDialog(null, "ERRO ao Efeturar Atualização - Codigo Erro: 004-P.");
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO TENTAR ATUALIZAR O CLIENTE: Verifique Com o Administrador !!"+ex);
        }finally{
            ConnectionDB.closeConnection(conn, stmt);
        }
    }
    
    
    
}
