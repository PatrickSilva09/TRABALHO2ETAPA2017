package main;

import Model.Pessoa;
import Model.Usuario;
import view.LoginView;

public class Principal {

    public static void main(String[] args) {
        LoginView login = new LoginView();
    }
    
}
