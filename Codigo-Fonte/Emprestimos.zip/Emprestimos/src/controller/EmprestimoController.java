package controller;

import DAO.EmprestimoDAO;
import DAO.TransacaoDAO;
import Model.Emprestimo;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class EmprestimoController {
    private EmprestimoDAO emprestimo;
    
    
    public EmprestimoController(){
        this.emprestimo = new EmprestimoDAO();
    }
    
    
    public void newTransacao(String valor, int idPessoa, String tipo){
        
        
        if( valor == "" ){
            JOptionPane.showMessageDialog(null, "O Valor Estar Vazio");
        }
        else {
            double v = Double.parseDouble(valor);
            
            if( v <= 0 ){
                JOptionPane.showMessageDialog(null, "Valor Invalido, Não e Possivel De Efetuar Transação com esse valor RS: "+valor);
            }
            else{
                TransacaoDAO trans  = new TransacaoDAO();
                trans.create(v, idPessoa, tipo);
            }
        }

    }
   
    public Emprestimo selectEmprestimoById(int idEmprestimo){
         if( idEmprestimo > 0){
            
            return emprestimo.selectEmprestimoById(idEmprestimo);
            
         }
        else {
             JOptionPane.showMessageDialog(null, "O Valor Estar Vazio");
             return null;
         }
    }
    
    public void updateStatusEmprestimo(int idEmprestimo, String status){
           
            if(emprestimo.updateStatusEmprestimo(idEmprestimo, status) > 0){
                JOptionPane.showMessageDialog(null, "Emprestimo Aprovado com Sucesso.");
            }
            else{
                JOptionPane.showMessageDialog(null, "ERRO ao Efeturar Aprovação do Emprestimo.");
            }
    }
    
    public void listEmprestimoPedentesJTable(DefaultTableModel modelo){
        modelo.setNumRows(0);
        EmprestimoDAO emprestimo = new EmprestimoDAO();
        
        for(Emprestimo e: emprestimo.selectEmprestimoPendentes()){
            modelo.addRow(new Object[]{
                e.getIdEmprestimo(),
                e.getDescricao(),
                e.getDataSolicitacao(),
                "R$ "+e.getValorSolicitado(),
                e.getNumeroParcelas(),
                e.getNome(),
                e.getStatus()
            });
        }
        
    }
    
    public void listAllEmprestimoJTable(DefaultTableModel modelo){
        modelo.setNumRows(0);
        EmprestimoDAO emprestimo = new EmprestimoDAO();
        
        for(Emprestimo e: emprestimo.selectAllEmprestimo()){
            modelo.addRow(new Object[]{
                e.getIdEmprestimo(),
                e.getDescricao(),
                e.getDataSolicitacao(),
                "R$ "+e.getValorSolicitado(),
                e.getNumeroParcelas(),
                e.getNome(),
                e.getStatus()
            });
        }
        
    }
    
     public void create(Emprestimo emp){
        if( emp == null ){
            JOptionPane.showMessageDialog(null, "Por Favor Informe Os dados Necessarios, Campos Vazios");
        }
        else {      
            this.emprestimo.create(emp);
        }

    }
    
    
    
}
