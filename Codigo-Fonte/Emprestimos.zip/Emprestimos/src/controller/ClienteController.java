package controller;

import DAO.ClienteDAO;
import Model.Cliente;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ClienteController {
    
    private ClienteDAO cliDAO;
    
    public ClienteController(){
        this.cliDAO = new ClienteDAO();
    }
    
    public void create(Cliente cli){
        if( cli == null ){
            JOptionPane.showMessageDialog(null, "Por Favor Informe Os dados Necessarios, Campos Vazios");
        }
        else {      
            this.cliDAO.create(cli);
        }

    }
    
    public void update(Cliente cli){
        if( cli == null ){
            JOptionPane.showMessageDialog(null, "Por Favor Informe Os dados Necessarios, Campos Vazios");
        }
        else {
            this.cliDAO.update(cli);
        }

    }
    
    public void listClienteJTable(DefaultTableModel modelo){
        modelo.setNumRows(0);
        
        for(Cliente e: this.cliDAO.selectAllClientes()){
            modelo.addRow(new Object[]{
                e.getIdPessoa(),
                e.getNome(),
                e.getCpf(),
                e.getEndereco(),
                e.getEmail(),
                e.getSaldo()
            });
        }        
    }
    
    public Cliente selectClienteById(int idPessoa){
         if( idPessoa > 0){
            
            return cliDAO.selectClienteById(idPessoa);
            
         }
        else {
             JOptionPane.showMessageDialog(null, "O Valor Estar Vazio");
             return null;
         }
    }
    
    public Cliente selectClienteByCpf(String cpf){
        if( cpf != null ){
           return cliDAO.selectClienteByCpf(cpf);
            
        }
        else {
             JOptionPane.showMessageDialog(null, "O Valor Estar Vazio");
             return null;
         }
    }
    
    
}
