package controller;

import DAO.TransacaoDAO;
import Model.Cliente;
import Model.TransacaoBancaria;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TransacaoController {
    
    public void newTransacao(String valor, int idPessoa, String tipo){
        
        
        if( valor == "" ){
            JOptionPane.showMessageDialog(null, "O Valor Estar Vazio");
        }
        else {
            double v = Double.parseDouble(valor);
            
            if( v <= 0 ){
                JOptionPane.showMessageDialog(null, "Valor Invalido, Não e Possivel De Efetuar Transação com esse valor RS: "+valor);
            }
            else{
                TransacaoDAO trans  = new TransacaoDAO();
                trans.create(v, idPessoa, tipo);
            }
        }

    }
    
    public void listTransacaoJTable(DefaultTableModel modelo, Cliente cli){
        modelo.setNumRows(0);
        TransacaoDAO extrado = new TransacaoDAO();
        
        for(TransacaoBancaria e: extrado.selectExtratoByIdPessoa(cli.getIdPessoa())){
            modelo.addRow(new Object[]{
                e.getData(),
                "R$ "+e.getValor(),
                e.getTipo()              
            });
        }
        
    }

    
}
