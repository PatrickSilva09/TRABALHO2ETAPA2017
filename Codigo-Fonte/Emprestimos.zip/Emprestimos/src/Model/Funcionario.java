package Model;

public class Funcionario extends Pessoa {
    private int idFuncionario;
    private String cargo;

    public Funcionario() {
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        if(cargo.equals("G")){
            this.cargo = "GERENTE";
        }
        else{
            this.cargo = cargo;
        }
    }
    
    
}
